# Guardian_AI - AI Identity Verification & Deepfake Detection

```
Guardian_AI/
├── data/
│   ├── raw/{real,fake}/      original images or videos (download_data.py fills this)
│   ├── real/  fake/          face crops used for training
├── deepfake/                 extract_frames, face_crop, data_utils, model, train_vit, predict, evaluate
├── face_verification/verify.py
├── liveness/liveness.py
├── fusion/scoring.py
├── api/main.py
├── download_data.py   make_sample_data.py   smoke_test.py
├── requirements.txt   README.md
```
Run every command from the project root (the folder containing `deepfake/`), using `python -m package.module`.

## 1. Setup (VS Code)
```
python -m venv .venv
.venv\Scripts\activate            # Windows      (Mac/Linux: source .venv/bin/activate)
pip install -r requirements.txt
```
In VS Code: Ctrl+Shift+P -> "Python: Select Interpreter" -> pick `.venv`, then use the built-in terminal.
`opencv-python` must be 4.x (version 5 has no Haar face/eye detector files).

## 2. Check that everything works
```
python smoke_test.py
```
Uses synthetic data, downloads nothing. Expect `[PASS]` everywhere; `[SKIP]` means a package is missing.
(If you installed facenet-pytorch, the verification step downloads its weights once.)

## 3. Real data from Kaggle (small)
One-time: `pip install kaggle`, then Kaggle -> Settings -> API -> Create New Token, and put `kaggle.json` in `~/.kaggle/`
(Windows: `C:\Users\<you>\.kaggle\`).
```
python download_data.py                       # ciplab/real-and-fake-face-detection, 300 images per class
python -m deepfake.face_crop --src_root data/raw --dst_root data
python -m deepfake.train_vit --epochs 5       # first run downloads ImageNet ViT-Tiny weights
python -m deepfake.evaluate                   # reports/metrics.json + confusion_matrix.png
python -m deepfake.evaluate --explain data/fake/<some>.jpg   # heat-map in reports/
python -m deepfake.predict data/fake/<some>.jpg
```
Other options: `--dataset sachchitkunichetty/rvf10k` (StyleGAN fakes vs real faces), `--max_per_class 1000`.
Videos instead of images: put them in `data/raw/real` and `data/raw/fake`, then
`python -m deepfake.extract_frames` and `python -m deepfake.face_crop --src_root data/frames --dst_root data`.
No GPU? Use `--epochs 3 --batch 8 --max_per_class 200` for a quick CPU run.

## 4. The other modules
```
python -m face_verification.verify a.jpg b.jpg
python -m liveness.liveness --webcam            # or --video clip.mp4
python -m fusion.scoring --deepfake 0.2 --liveness 0.9 --similarity 0.7
```
For real face verification: `pip install facenet-pytorch` (if pip complains about torch/numpy versions: `pip install facenet-pytorch --no-deps`).
Without it a weak LBP fallback is used - fine for testing the plumbing, not for decisions.

## 5. API
```
uvicorn api.main:app --reload        # http://127.0.0.1:8000/docs
curl -F "media=@photo.jpg" -F "reference=@id.jpg" -F "liveness_video=@clip.mp4" http://127.0.0.1:8000/analyze
```
Endpoints: `GET /health`, `POST /deepfake`, `POST /verify`, `POST /liveness`, `POST /analyze` (runs what it is given and fuses it).
Set `GUARDIAN_CKPT` to point at another model file.

## 6. Train on Kaggle (free GPU)
New notebook -> Settings: Accelerator = GPU, Internet = On. Add Data: "real and fake face detection" (ciplab) and your uploaded code zip.
```
%cd /kaggle/working
!cp -r /kaggle/input/<your-code-dataset>/Guardian_AI .      # adjust to the path shown in the Data panel
%cd Guardian_AI
!pip -q install timm
!python download_data.py --from_dir /kaggle/input/real-and-fake-face-detection
!python -m deepfake.face_crop
!python -m deepfake.train_vit --epochs 5 --batch 32
```
Download `models/vit_deepfake.pt` from the notebook's Output panel and put it in your local `models/` folder.

## Limits (read before trusting any number)
- Small data: the model learns that dataset's quirks. Expect modest accuracy on the ciplab set and poor transfer to other deepfake types.
- Train/val are split by video/image group; keep it that way or your scores will be inflated.
- Liveness uses simple heuristics: it stops a held-up photo, not a replayed video. Add a trained anti-spoofing model or a challenge step for real use.
- Fusion weights and thresholds are hand-set, not calibrated; tune them on your own validation data.
- This handles biometric data: get consent, and test for bias across skin tones, ages and cameras before any real use.
