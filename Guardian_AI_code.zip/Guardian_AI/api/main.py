"""FastAPI service tying the modules together.

Run from the project root:
    uvicorn api.main:app --reload
Docs UI: http://127.0.0.1:8000/docs
Set GUARDIAN_CKPT to use a different model file (default models/vit_deepfake.pt).
"""
import os
import tempfile
import threading
from typing import Optional

import cv2
import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile

from deepfake.data_utils import VIDEO_EXTS, sample_video_frames
from face_verification.verify import FaceVerifier
from fusion.scoring import fuse
from liveness.liveness import analyze_video

CKPT = os.environ.get("GUARDIAN_CKPT", "models/vit_deepfake.pt")
app = FastAPI(title="Guardian_AI", version="0.1.0")

_lock = threading.Lock()
_cache = {"detector": None, "verifier": None}


def get_detector():
    with _lock:
        if _cache["detector"] is None:
            if not os.path.exists(CKPT):
                raise HTTPException(503, f"Deepfake model not found at '{CKPT}'. Train one first (python -m deepfake.train_vit).")
            try:
                from deepfake.predict import DeepfakeDetector  # imports torch lazily
                _cache["detector"] = DeepfakeDetector(CKPT)
            except ImportError as e:
                raise HTTPException(503, f"PyTorch/timm not installed: {e}")
        return _cache["detector"]


def get_verifier():
    with _lock:
        if _cache["verifier"] is None:
            _cache["verifier"] = FaceVerifier("auto")
        return _cache["verifier"]


def _is_video(name):
    return os.path.splitext(name or "")[1].lower() in VIDEO_EXTS


def _decode_image(data):
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(400, "Could not decode the uploaded image.")
    return img


def _to_temp(data, filename):
    suffix = os.path.splitext(filename or "")[1] or ".mp4"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
        f.write(data)
        return f.name


def _deepfake(data, filename):
    det = get_detector()
    if _is_video(filename):
        path = _to_temp(data, filename)
        try:
            return det.predict_video(path)
        except IOError as e:
            raise HTTPException(400, str(e))
        finally:
            os.remove(path)
    return det.predict_image(_decode_image(data))


def _liveness(data, filename):
    path = _to_temp(data, filename)
    try:
        return analyze_video(path)
    except IOError as e:
        raise HTTPException(400, str(e))
    finally:
        os.remove(path)


def _first_frame(data, filename):
    """An image for identity comparison: the image itself, or the middle frame of a video."""
    if not _is_video(filename):
        return _decode_image(data)
    path = _to_temp(data, filename)
    try:
        frames = sample_video_frames(path, 3)
    finally:
        os.remove(path)
    if not frames:
        raise HTTPException(400, "Could not read frames from the uploaded video.")
    return frames[len(frames) // 2]


@app.get("/health")
def health():
    return {"status": "ok", "deepfake_model_found": os.path.exists(CKPT), "checkpoint": CKPT}


@app.post("/deepfake")
def deepfake(media: UploadFile = File(..., description="image or video")):
    return _deepfake(media.file.read(), media.filename)


@app.post("/verify")
def verify(image1: UploadFile = File(...), image2: UploadFile = File(...)):
    img1, img2 = _decode_image(image1.file.read()), _decode_image(image2.file.read())
    return get_verifier().verify(img1, img2)


@app.post("/liveness")
def liveness(video: UploadFile = File(..., description="short video (3-5 s) of the person")):
    return _liveness(video.file.read(), video.filename)


@app.post("/analyze")
def analyze(media: UploadFile = File(..., description="image or video to check"),
            reference: Optional[UploadFile] = File(None, description="reference face image (optional)"),
            liveness_video: Optional[UploadFile] = File(None, description="short live video (optional)")):
    """Runs every module it has input for and fuses the results."""
    media_bytes = media.file.read()
    result, notes = {}, []

    try:
        result["deepfake"] = _deepfake(media_bytes, media.filename)
    except HTTPException as e:
        if e.status_code != 503:
            raise
        notes.append(f"deepfake skipped: {e.detail}")

    if reference is not None:
        v = get_verifier().verify(_first_frame(media_bytes, media.filename), _decode_image(reference.file.read()))
        result["verification"] = v
    if liveness_video is not None:
        result["liveness"] = _liveness(liveness_video.file.read(), liveness_video.filename)

    sims = result.get("verification")
    if sims and sims["backend"] == "lbp":
        notes.append("verification used the weak LBP fallback and was NOT used in the final decision")
        sims = None
    try:
        result["decision"] = fuse(
            deepfake_fake_prob=result["deepfake"]["fake_prob"] if "deepfake" in result else None,
            liveness_score=result["liveness"]["live_score"] if "liveness" in result else None,
            similarity=sims["similarity"] if sims else None,
            id_threshold=sims["threshold"] if sims else 0.5)
    except ValueError:
        raise HTTPException(400, "No usable signal. " + " ".join(notes))
    if notes:
        result["notes"] = notes
    return result
