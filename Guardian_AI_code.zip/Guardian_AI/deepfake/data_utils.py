"""Torch-free helpers shared by training, prediction and the API."""
import os
import random
import re

import cv2
import numpy as np

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".webm"}
CLASSES = ["real", "fake"]  # label 0 = real, label 1 = fake


def list_files(folder, exts):
    out = []
    for root, _, files in os.walk(folder):
        for f in files:
            if os.path.splitext(f)[1].lower() in exts:
                out.append(os.path.join(root, f))
    return sorted(out)


def list_samples(data_dir):
    """[(path, label)] from data_dir/real (label 0) and data_dir/fake (label 1)."""
    items = []
    for label, cls in enumerate(CLASSES):
        for p in list_files(os.path.join(data_dir, cls), IMG_EXTS):
            items.append((p, label))
    return items


_FRAME_RE = re.compile(r"_f\d+$")


def group_key(path):
    """Frames of one video (name_f00010.jpg) share a group, so they never land in train AND val."""
    stem = os.path.splitext(os.path.basename(path))[0]
    return _FRAME_RE.sub("", stem)


def group_split(items, val_fraction=0.2, seed=42):
    """Split by group, separately for each class. Returns (train_items, val_items)."""
    rng = random.Random(seed)
    train, val = [], []
    for label in range(len(CLASSES)):
        groups = {}
        for p, y in items:
            if y == label:
                groups.setdefault(group_key(p), []).append((p, y))
        keys = sorted(groups)
        rng.shuffle(keys)
        n_val = int(round(len(keys) * val_fraction))
        n_val = min(max(n_val, 1), len(keys) - 1) if len(keys) >= 2 else 0
        for i, k in enumerate(keys):
            (val if i < n_val else train).extend(groups[k])
    return train, val


def preprocess_bgr(img_bgr, size=224):
    """BGR uint8 image -> float32 CHW array in [-1, 1] (same for training and inference)."""
    interp = cv2.INTER_AREA if min(img_bgr.shape[:2]) > size else cv2.INTER_LINEAR
    img = cv2.resize(img_bgr, (size, size), interpolation=interp)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    img = (img - 0.5) / 0.5
    return np.ascontiguousarray(img.transpose(2, 0, 1))


def augment_bgr(img, rng=random):
    """Light augmentation: flip, random crop (85-100%), brightness/contrast."""
    h, w = img.shape[:2]
    if rng.random() < 0.5:
        img = img[:, ::-1]
    s = rng.uniform(0.85, 1.0)
    ch, cw = max(8, int(h * s)), max(8, int(w * s))
    y0, x0 = rng.randint(0, h - ch), rng.randint(0, w - cw)
    img = np.ascontiguousarray(img[y0:y0 + ch, x0:x0 + cw])
    return cv2.convertScaleAbs(img, alpha=rng.uniform(0.85, 1.15), beta=rng.uniform(-15, 15))


def sample_video_frames(path, num_frames=16):
    """Evenly spaced frames (BGR) from a video file."""
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError(f"Cannot open video: {path}")
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    frames = []
    if total > 0:
        for i in np.linspace(0, total - 1, num=min(num_frames, total)).astype(int):
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(i))
            ok, f = cap.read()
            if ok:
                frames.append(f)
    cap.release()
    if not frames:  # frame count unknown / seeking failed -> read sequentially (max 600 frames)
        cap = cv2.VideoCapture(path)
        allf = []
        while len(allf) < 600:
            ok, f = cap.read()
            if not ok:
                break
            allf.append(f)
        cap.release()
        if allf:
            idx = np.linspace(0, len(allf) - 1, num=min(num_frames, len(allf))).astype(int)
            frames = [allf[i] for i in idx]
    return frames


def read_consecutive_frames(source, max_frames=90):
    """First max_frames consecutive frames from a file path or webcam index. Returns (frames, fps)."""
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise IOError(f"Cannot open video source: {source}")
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0) or 30.0
    frames = []
    while len(frames) < max_frames:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    return frames, fps
