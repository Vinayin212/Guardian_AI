"""Evaluation + a simple explanation map.

    python -m deepfake.evaluate                      # metrics on the validation split saved by training
    python -m deepfake.evaluate --explain face.jpg   # occlusion heat-map: which regions push the score toward "fake"
Outputs go to reports/.
"""
import argparse
import json
import os

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics import (accuracy_score, confusion_matrix, precision_recall_fscore_support,
                             roc_auc_score)
from torch.utils.data import DataLoader

from deepfake.data_utils import CLASSES, preprocess_bgr
from deepfake.face_crop import crop_face
from deepfake.model import load_checkpoint, pick_device
from deepfake.train_vit import FaceDataset


@torch.no_grad()
def evaluate(ckpt, split_json, out_dir, batch=16):
    device = pick_device()
    model, c = load_checkpoint(ckpt, device)
    with open(split_json) as f:
        val = json.load(f)["val"]
    if not val:
        raise SystemExit("Validation split is empty - add more data or lower --val_fraction in training.")
    probs, labels = [], []
    for x, y in DataLoader(FaceDataset([tuple(v) for v in val], c["img_size"]), batch_size=batch):
        probs += torch.softmax(model(x.to(device)), 1)[:, 1].cpu().tolist()
        labels += y.tolist()
    probs, labels = np.array(probs), np.array(labels)
    pred = (probs >= 0.5).astype(int)
    p, r, f1, _ = precision_recall_fscore_support(labels, pred, average="binary", pos_label=1, zero_division=0)
    cm = confusion_matrix(labels, pred, labels=[0, 1])
    metrics = {"n": int(len(labels)), "accuracy": float(accuracy_score(labels, pred)),
               "precision_fake": float(p), "recall_fake": float(r), "f1_fake": float(f1),
               "roc_auc": float(roc_auc_score(labels, probs)) if len(set(labels.tolist())) == 2 else None,
               "confusion_matrix [rows=true real/fake, cols=pred real/fake]": cm.tolist()}
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)
    fig, ax = plt.subplots(figsize=(3.6, 3.2))
    ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1], CLASSES)
    ax.set_yticks([0, 1], CLASSES)
    ax.set_xlabel("predicted")
    ax.set_ylabel("true")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cm[i, j], ha="center", va="center")
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "confusion_matrix.png"), dpi=150)
    plt.close(fig)
    print(json.dumps(metrics, indent=2))
    return metrics


@torch.no_grad()
def occlusion_map(model, face_bgr, device, size=224, patch=48, stride=24, batch=32):
    """Grey out one square at a time; the drop in fake-probability shows how much that area mattered."""
    x0 = preprocess_bgr(face_bgr, size)  # normalised, so 0.0 is mid-grey

    def fake_prob(arrs):
        out = []
        for i in range(0, len(arrs), batch):
            t = torch.from_numpy(np.stack(arrs[i:i + batch])).to(device)
            out += torch.softmax(model(t), 1)[:, 1].cpu().tolist()
        return out

    base = fake_prob([x0])[0]
    variants, boxes = [], []
    for y in range(0, size - patch + 1, stride):
        for x in range(0, size - patch + 1, stride):
            v = x0.copy()
            v[:, y:y + patch, x:x + patch] = 0.0
            variants.append(v)
            boxes.append((y, x))
    heat, cnt = np.zeros((size, size)), np.zeros((size, size))
    for (y, x), p in zip(boxes, fake_prob(variants)):
        heat[y:y + patch, x:x + patch] += base - p
        cnt[y:y + patch, x:x + patch] += 1
    return base, heat / np.maximum(cnt, 1)


def explain(ckpt, image_path, out_dir):
    device = pick_device()
    model, c = load_checkpoint(ckpt, device)
    img = cv2.imread(image_path)
    if img is None:
        raise SystemExit(f"Cannot read image: {image_path}")
    face, _ = crop_face(img, size=c["img_size"])
    base, heat = occlusion_map(model, face, device, size=c["img_size"])
    h = np.clip(heat, 0, None)
    h = h / h.max() if h.max() > 0 else h
    color = cv2.applyColorMap((h * 255).astype(np.uint8), cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(face, 0.6, color, 0.4, 0)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "explain_" + os.path.splitext(os.path.basename(image_path))[0] + ".png")
    cv2.imwrite(path, np.hstack([face, overlay]))
    print(f"fake probability {base:.3f}; heat-map saved to {path} (red = pushes toward 'fake')")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Evaluate the deepfake model / explain a prediction")
    ap.add_argument("--ckpt", default="models/vit_deepfake.pt")
    ap.add_argument("--split", default="models/split.json")
    ap.add_argument("--out", default="reports")
    ap.add_argument("--explain", metavar="IMAGE")
    a = ap.parse_args(argv)
    if a.explain:
        explain(a.ckpt, a.explain, a.out)
    else:
        evaluate(a.ckpt, a.split, a.out)


if __name__ == "__main__":
    main()
