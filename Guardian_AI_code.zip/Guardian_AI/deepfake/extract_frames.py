"""Extract frames from videos.

    python -m deepfake.extract_frames --src_root data/raw --dst_root data/frames --every 10 --max_frames 20
Expects videos in <src_root>/real and <src_root>/fake. Output names end in _fNNNNN so the
train/val split keeps all frames of one video on the same side (no leakage).
"""
import argparse
import os

import cv2

from deepfake.data_utils import CLASSES, VIDEO_EXTS, list_files


def extract(video_path, out_dir, stem, every=10, max_frames=20):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"[extract_frames] cannot open {video_path}")
        return 0
    saved = idx = 0
    while saved < max_frames:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % every == 0:
            cv2.imwrite(os.path.join(out_dir, f"{stem}_f{idx:05d}.jpg"), frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
            saved += 1
        idx += 1
    cap.release()
    return saved


def main(argv=None):
    ap = argparse.ArgumentParser(description="Extract frames from videos")
    ap.add_argument("--src_root", default="data/raw")
    ap.add_argument("--dst_root", default="data/frames")
    ap.add_argument("--every", type=int, default=10, help="keep every Nth frame")
    ap.add_argument("--max_frames", type=int, default=20, help="max frames per video")
    a = ap.parse_args(argv)
    for cls in CLASSES:
        src, dst = os.path.join(a.src_root, cls), os.path.join(a.dst_root, cls)
        videos = list_files(src, VIDEO_EXTS)
        os.makedirs(dst, exist_ok=True)
        total = 0
        for v in videos:
            stem = os.path.splitext(os.path.relpath(v, src))[0].replace(os.sep, "__")
            total += extract(v, dst, stem, a.every, a.max_frames)
        print(f"[extract_frames] {cls}: {len(videos)} videos -> {total} frames in {dst}")


if __name__ == "__main__":
    main()
