"""Detect and crop faces with OpenCV's Haar cascade.

Run from the project root:
    python -m deepfake.face_crop --src_root data/raw --dst_root data
For video frames: --src_root data/frames
If no face is found, the image is center-cropped instead (use --no_fallback to skip such images).
"""
import argparse
import os

import cv2

from deepfake.data_utils import CLASSES, IMG_EXTS, list_files

_detector = None
_ready = False


def set_detector(fn):
    """Plug in your own detector: fn(img_bgr) -> list of (x, y, w, h)."""
    global _detector, _ready
    _detector, _ready = fn, True


def _load_haar():
    if not hasattr(cv2, "CascadeClassifier"):
        return None
    base = getattr(getattr(cv2, "data", None), "haarcascades", None)
    path = os.environ.get("GUARDIAN_FACE_CASCADE") or (
        os.path.join(base, "haarcascade_frontalface_default.xml") if base else None)
    if not path or not os.path.exists(path):
        return None
    clf = cv2.CascadeClassifier(path)
    if clf.empty():
        return None

    def detect(img_bgr):
        h, w = img_bgr.shape[:2]
        scale = 640.0 / max(h, w) if max(h, w) > 640 else 1.0
        small = cv2.resize(img_bgr, None, fx=scale, fy=scale) if scale != 1.0 else img_bgr
        gray = cv2.equalizeHist(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))
        m = max(30, int(min(gray.shape[:2]) * 0.1))
        boxes = clf.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(m, m))
        return [tuple(int(v / scale) for v in b) for b in boxes]

    return detect


def detect_faces(img_bgr):
    global _detector, _ready
    if not _ready:
        _detector, _ready = _load_haar(), True
        if _detector is None:
            print("[face_crop] WARNING: no face detector available "
                  "(install opencv-python<5, or set GUARDIAN_FACE_CASCADE). Using center crops.")
    return list(_detector(img_bgr)) if _detector else []


def largest_face(img_bgr):
    faces = detect_faces(img_bgr)
    return max(faces, key=lambda b: b[2] * b[3]) if faces else None


def crop_face(img_bgr, size=224, margin=0.3, fallback=True):
    """Returns (crop_resized_to_size, face_found). crop is None if no face and fallback=False."""
    h, w = img_bgr.shape[:2]
    box = largest_face(img_bgr)
    if box is not None:
        x, y, bw, bh = box
        side = max(bw, bh) * (1 + margin)
        cx, cy = x + bw / 2, y + bh / 2
        x0, y0 = int(max(0, cx - side / 2)), int(max(0, cy - side / 2))
        x1, y1 = int(min(w, cx + side / 2)), int(min(h, cy + side / 2))
        crop, found = img_bgr[y0:y1, x0:x1], True
    elif fallback:
        s = min(h, w)
        y0, x0 = (h - s) // 2, (w - s) // 2
        crop, found = img_bgr[y0:y0 + s, x0:x0 + s], False
    else:
        return None, False
    interp = cv2.INTER_AREA if min(crop.shape[:2]) > size else cv2.INTER_LINEAR
    return cv2.resize(crop, (size, size), interpolation=interp), found


def process_folder(src, dst, size=224, margin=0.3, fallback=True):
    os.makedirs(dst, exist_ok=True)
    stats = {"face": 0, "center_fallback": 0, "skipped": 0}
    for p in list_files(src, IMG_EXTS):
        img = cv2.imread(p)
        crop, found = (None, False) if img is None else crop_face(img, size, margin, fallback)
        if crop is None:
            stats["skipped"] += 1
            continue
        name = os.path.splitext(os.path.relpath(p, src))[0].replace(os.sep, "__")
        cv2.imwrite(os.path.join(dst, name + ".jpg"), crop, [cv2.IMWRITE_JPEG_QUALITY, 95])
        stats["face" if found else "center_fallback"] += 1
    return stats


def main(argv=None):
    ap = argparse.ArgumentParser(description="Crop faces from images into data/real and data/fake")
    ap.add_argument("--src_root", default="data/raw")
    ap.add_argument("--dst_root", default="data")
    ap.add_argument("--size", type=int, default=224)
    ap.add_argument("--margin", type=float, default=0.3)
    ap.add_argument("--no_fallback", action="store_true")
    a = ap.parse_args(argv)
    for cls in CLASSES:
        src = os.path.join(a.src_root, cls)
        if not os.path.isdir(src):
            print(f"[face_crop] missing folder {src}, skipping")
            continue
        print(f"[face_crop] {cls}: {process_folder(src, os.path.join(a.dst_root, cls), a.size, a.margin, not a.no_fallback)}")


if __name__ == "__main__":
    main()
