"""Model helpers (PyTorch + timm)."""
import os

import torch
import timm

from deepfake.data_utils import CLASSES

IMG_SIZE = 224


def build_model(arch="vit_tiny_patch16_224", pretrained=True, num_classes=2):
    try:
        return timm.create_model(arch, pretrained=pretrained, num_classes=num_classes)
    except Exception as e:
        if not pretrained:
            raise
        print(f"[model] could not load pretrained weights ({type(e).__name__}: {e}); training from scratch instead.")
        return timm.create_model(arch, pretrained=False, num_classes=num_classes)


def pick_device():
    if torch.cuda.is_available():
        return torch.device("cuda")
    mps = getattr(torch.backends, "mps", None)
    if mps is not None and mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def save_checkpoint(path, model, arch, **extra):
    """extra values must be plain numbers/strings so torch.load(weights_only=True) can read them."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    torch.save({"arch": arch, "img_size": IMG_SIZE, "classes": list(CLASSES),
                "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()}, **extra}, path)


def load_checkpoint(path, device):
    ckpt = torch.load(path, map_location=device)
    model = build_model(ckpt["arch"], pretrained=False)
    model.load_state_dict(ckpt["state_dict"])
    return model.to(device).eval(), ckpt
