"""Run the trained deepfake classifier on an image or a video.

    python -m deepfake.predict path/to/file.jpg --ckpt models/vit_deepfake.pt
"""
import argparse
import json
import os

import numpy as np
import torch

from deepfake.data_utils import VIDEO_EXTS, preprocess_bgr, sample_video_frames
from deepfake.face_crop import crop_face
from deepfake.model import load_checkpoint, pick_device


class DeepfakeDetector:
    def __init__(self, ckpt_path="models/vit_deepfake.pt", device=None, threshold=0.5):
        self.device = device or pick_device()
        self.model, ckpt = load_checkpoint(ckpt_path, self.device)
        self.size = int(ckpt.get("img_size", 224))
        self.threshold = threshold

    @torch.no_grad()
    def fake_probs(self, faces_bgr, batch=16):
        probs = []
        for i in range(0, len(faces_bgr), batch):
            x = np.stack([preprocess_bgr(f, self.size) for f in faces_bgr[i:i + batch]])
            logits = self.model(torch.from_numpy(x).to(self.device))
            probs += torch.softmax(logits, 1)[:, 1].cpu().tolist()
        return [float(p) for p in probs]

    def _result(self, probs, found_flags, frames):
        p = float(np.mean(probs))
        return {"fake_prob": round(p, 4), "label": "fake" if p >= self.threshold else "real",
                "frames_used": len(probs), "frames_sampled": frames,
                "face_found": bool(any(found_flags)),
                "frame_probs": [round(x, 4) for x in probs]}

    def predict_image(self, img_bgr):
        crop, found = crop_face(img_bgr)
        return self._result(self.fake_probs([crop]), [found], 1)

    def predict_video(self, path, num_frames=16):
        frames = sample_video_frames(path, num_frames)
        if not frames:
            raise IOError(f"No frames could be read from {path}")
        crops = [crop_face(f) for f in frames]
        with_face = [c for c, found in crops if found]
        use = with_face if with_face else [c for c, _ in crops]  # prefer frames with a detected face
        return self._result(self.fake_probs(use), [bool(with_face)], len(frames))

    def predict_path(self, path):
        if os.path.splitext(path)[1].lower() in VIDEO_EXTS:
            return self.predict_video(path)
        import cv2
        img = cv2.imread(path)
        if img is None:
            raise IOError(f"Cannot read image: {path}")
        return self.predict_image(img)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Predict real/fake for an image or video")
    ap.add_argument("input")
    ap.add_argument("--ckpt", default="models/vit_deepfake.pt")
    ap.add_argument("--threshold", type=float, default=0.5)
    a = ap.parse_args(argv)
    print(json.dumps(DeepfakeDetector(a.ckpt, threshold=a.threshold).predict_path(a.input), indent=2))


if __name__ == "__main__":
    main()
