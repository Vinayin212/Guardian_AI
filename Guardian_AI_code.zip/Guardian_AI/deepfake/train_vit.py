"""Fine-tune a small Vision Transformer (ViT-Tiny) to classify face crops as real (0) / fake (1).

    python -m deepfake.train_vit --data data --epochs 5
Needs images in data/real and data/fake (see README). Saves models/vit_deepfake.pt and
models/split.json (the exact validation files, reused by deepfake.evaluate).
"""
import argparse
import json
import os
import random
import sys
import time

import cv2
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader, Dataset

from deepfake.data_utils import CLASSES, augment_bgr, group_split, list_samples, preprocess_bgr
from deepfake.model import IMG_SIZE, build_model, pick_device, save_checkpoint


class FaceDataset(Dataset):
    def __init__(self, items, size=IMG_SIZE, train=False):
        self.items, self.size, self.train = items, size, train

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        path, label = self.items[i]
        img = cv2.imread(path)
        if img is None:
            raise IOError(f"Cannot read image: {path}")
        if self.train:
            img = augment_bgr(img)
        return torch.from_numpy(preprocess_bgr(img, self.size)), label


def run_epoch(model, loader, device, criterion, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total_loss, n, probs, labels = 0.0, 0, [], []
    with torch.set_grad_enabled(training):
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss = criterion(logits, y)
            if training:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
            total_loss += loss.item() * x.size(0)
            n += x.size(0)
            probs += torch.softmax(logits, 1)[:, 1].detach().cpu().tolist()
            labels += y.cpu().tolist()
    probs, labels = np.array(probs), np.array(labels)
    acc = float(((probs >= 0.5) == (labels == 1)).mean()) if n else float("nan")
    auc = float(roc_auc_score(labels, probs)) if len(set(labels.tolist())) == 2 else float("nan")
    return {"loss": total_loss / max(n, 1), "acc": acc, "auc": auc}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Train the ViT deepfake classifier")
    ap.add_argument("--data", default="data")
    ap.add_argument("--arch", default="vit_tiny_patch16_224")
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--val_fraction", type=float, default=0.2)
    ap.add_argument("--max_per_class", type=int, default=0, help="0 = use everything")
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--no_pretrained", action="store_true", help="skip downloading ImageNet weights")
    ap.add_argument("--out", default="models/vit_deepfake.pt")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args(argv)

    random.seed(a.seed)
    np.random.seed(a.seed)
    torch.manual_seed(a.seed)

    items = list_samples(a.data)
    counts = [sum(1 for _, y in items if y == c) for c in range(len(CLASSES))]
    if min(counts) == 0:
        sys.exit(f"Need images in both {a.data}/real and {a.data}/fake (found {dict(zip(CLASSES, counts))}). See README.")
    if a.max_per_class:
        rng = random.Random(a.seed)
        keep = []
        for c in range(len(CLASSES)):
            cls_items = [it for it in items if it[1] == c]
            rng.shuffle(cls_items)
            keep += cls_items[:a.max_per_class]
        items = keep

    train_items, val_items = group_split(items, a.val_fraction, a.seed)
    out_dir = os.path.dirname(a.out) or "."
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "split.json"), "w") as f:
        json.dump({"train": train_items, "val": val_items}, f)

    device = pick_device()
    print(f"device={device}  train={len(train_items)}  val={len(val_items)}  classes={CLASSES}")
    model = build_model(a.arch, pretrained=not a.no_pretrained).to(device)

    n = np.bincount([y for _, y in train_items], minlength=2).astype(np.float64)
    weights = torch.tensor(n.sum() / (2.0 * np.maximum(n, 1)), dtype=torch.float32, device=device)
    criterion = nn.CrossEntropyLoss(weight=weights)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.05)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(a.epochs, 1))

    train_loader = DataLoader(FaceDataset(train_items, train=True), batch_size=a.batch, shuffle=True, num_workers=a.workers)
    val_loader = DataLoader(FaceDataset(val_items), batch_size=a.batch, num_workers=a.workers) if val_items else None

    best, history = -1.0, []
    for epoch in range(1, a.epochs + 1):
        t0 = time.time()
        tr = run_epoch(model, train_loader, device, criterion, optimizer)
        scheduler.step()
        va = run_epoch(model, val_loader, device, criterion) if val_loader else None
        history.append({"epoch": epoch, "train": tr, "val": va})
        msg = f"epoch {epoch}/{a.epochs}  train loss {tr['loss']:.4f} acc {tr['acc']:.3f}"
        if va:
            msg += f" | val loss {va['loss']:.4f} acc {va['acc']:.3f} auc {va['auc']:.3f}"
        print(msg + f"  ({time.time() - t0:.0f}s)")

        score = (va["auc"] if not np.isnan(va["auc"]) else va["acc"]) if va else float(epoch)
        if score > best:
            best = score
            save_checkpoint(a.out, model, a.arch, epoch=epoch, val_acc=float(va["acc"]) if va else -1.0,
                            val_auc=float(va["auc"]) if va else -1.0)
            print(f"  saved {a.out}")

    with open(os.path.join(out_dir, "history.json"), "w") as f:
        json.dump(history, f, indent=2)
    print("done. Next: python -m deepfake.evaluate   |   python -m deepfake.predict <image-or-video>")


if __name__ == "__main__":
    main()
