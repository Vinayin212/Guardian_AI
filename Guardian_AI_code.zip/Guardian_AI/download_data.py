"""Get a small real/fake face dataset from Kaggle into data/raw/real and data/raw/fake.

  python download_data.py                                  # downloads ciplab/real-and-fake-face-detection
  python download_data.py --dataset sachchitkunichetty/rvf10k
  python download_data.py --from_dir /kaggle/input/real-and-fake-face-detection   # already downloaded / Kaggle notebook

Kaggle login (first time): kaggle.com -> Settings -> API -> Create New Token, then put the downloaded
kaggle.json in ~/.kaggle/ (Windows: C:\\Users\\<you>\\.kaggle\\) and `pip install kaggle`.
Images are sorted by their parent folder name: a folder containing 'fake' -> fake, else containing 'real' -> real.
"""
import argparse
import os
import random
import shutil
import subprocess
import sys

from deepfake.data_utils import IMG_EXTS


def kaggle_download(slug, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    try:
        subprocess.run(["kaggle", "datasets", "download", "-d", slug, "-p", out_dir, "--unzip"], check=True)
    except FileNotFoundError:
        sys.exit("The 'kaggle' command was not found. Run: pip install kaggle")
    except subprocess.CalledProcessError:
        sys.exit("Kaggle download failed. Check ~/.kaggle/kaggle.json (Kaggle > Settings > API > Create New Token), "
                 "your internet connection, and that you can open the dataset page in a browser.")


def classify(folder_name):
    n = folder_name.lower()
    if "fake" in n:
        return "fake"
    if "real" in n:
        return "real"
    return None


def organise(src_dir, dst_root, max_per_class, seed=42):
    found = {"real": [], "fake": []}
    for root, _, files in os.walk(src_dir):
        cls = classify(os.path.basename(root))
        if cls is None:
            continue
        found[cls] += [os.path.join(root, f) for f in files if os.path.splitext(f)[1].lower() in IMG_EXTS]
    if not found["real"] or not found["fake"]:
        sys.exit(f"Could not find both real and fake image folders under {src_dir} "
                 f"(real={len(found['real'])}, fake={len(found['fake'])}). Sort the images into data/raw/real and data/raw/fake manually.")
    rng = random.Random(seed)
    for cls, paths in found.items():
        rng.shuffle(paths)
        paths = sorted(paths[:max_per_class]) if max_per_class else sorted(paths)
        dst = os.path.join(dst_root, cls)
        os.makedirs(dst, exist_ok=True)
        for i, p in enumerate(paths):
            shutil.copy2(p, os.path.join(dst, f"{i:05d}_{os.path.basename(p)}"))
        print(f"{cls}: copied {len(paths)} of {len(found[cls])} images -> {dst}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Download / organise a small Kaggle deepfake dataset")
    ap.add_argument("--dataset", default="ciplab/real-and-fake-face-detection")
    ap.add_argument("--from_dir", help="skip download, use an existing folder")
    ap.add_argument("--dst", default="data/raw")
    ap.add_argument("--max_per_class", type=int, default=300, help="keep it small; 0 = all")
    ap.add_argument("--tmp", default="data/_download")
    a = ap.parse_args(argv)
    src = a.from_dir
    if not src:
        kaggle_download(a.dataset, a.tmp)
        src = a.tmp
    organise(src, a.dst, a.max_per_class)
    if not a.from_dir:
        print(f"You can delete {a.tmp} to save space.")
    print("Next: python -m deepfake.face_crop --src_root data/raw --dst_root data")


if __name__ == "__main__":
    main()
