"""Face verification: do two photos show the same person?

Backends
  facenet : InceptionResnetV1 (VGGFace2) from facenet-pytorch. Real accuracy. Weights download on first use.
  lbp     : tiny classical fallback (LBP histograms) so the pipeline runs without PyTorch.
            Weak - for testing the plumbing only, not for real decisions.

    python -m face_verification.verify a.jpg b.jpg [--backend auto|facenet|lbp] [--threshold 0.5]
The default thresholds are starting points; tune them on pairs from your own data.
"""
import argparse
import json

import cv2
import numpy as np

from deepfake.face_crop import crop_face


def _lbp_hist(gray, grid=4):
    g = gray.astype(np.int16)
    c = g[1:-1, 1:-1]
    code = np.zeros(c.shape, dtype=np.uint8)
    for bit, (dy, dx) in enumerate([(-1, -1), (-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1)]):
        nb = g[1 + dy:g.shape[0] - 1 + dy, 1 + dx:g.shape[1] - 1 + dx]
        code |= (nb >= c).astype(np.uint8) << bit
    ch, cw = code.shape[0] // grid, code.shape[1] // grid
    cells = []
    for i in range(grid):
        for j in range(grid):
            h = np.bincount(code[i * ch:(i + 1) * ch, j * cw:(j + 1) * cw].ravel(), minlength=256).astype(np.float32)
            cells.append(h / max(h.sum(), 1.0))
    return np.stack(cells)


class FaceVerifier:
    def __init__(self, backend="auto", threshold=None):
        self.backend, self._net, self._torch = None, None, None
        if backend in ("auto", "facenet"):
            try:
                import torch
                from facenet_pytorch import InceptionResnetV1
                self._torch = torch
                self._net = InceptionResnetV1(pretrained="vggface2").eval()
                self.backend = "facenet"
            except Exception as e:
                if backend == "facenet":
                    raise
                print(f"[verify] facenet backend unavailable ({type(e).__name__}: {e}). "
                      "Using the weak LBP fallback - install facenet-pytorch for real use.")
        if self.backend is None:
            self.backend = "lbp"
        self.threshold = threshold if threshold is not None else (0.5 if self.backend == "facenet" else 0.6)

    def _embed(self, face_bgr):
        if self.backend == "facenet":
            rgb = cv2.cvtColor(cv2.resize(face_bgr, (160, 160)), cv2.COLOR_BGR2RGB).astype(np.float32)
            x = self._torch.from_numpy(((rgb - 127.5) / 128.0).transpose(2, 0, 1)).unsqueeze(0)
            with self._torch.no_grad():
                e = self._net(x)[0].numpy()
            return e / (np.linalg.norm(e) + 1e-9)
        gray = cv2.cvtColor(cv2.resize(face_bgr, (64, 64)), cv2.COLOR_BGR2GRAY)
        return _lbp_hist(cv2.equalizeHist(gray))

    def similarity(self, face1_bgr, face2_bgr):
        e1, e2 = self._embed(face1_bgr), self._embed(face2_bgr)
        if self.backend == "facenet":
            return float(np.dot(e1, e2))              # cosine similarity, -1..1
        return float(np.minimum(e1, e2).sum(axis=1).mean())  # histogram intersection, 0..1

    def verify(self, img1_bgr, img2_bgr):
        f1, found1 = crop_face(img1_bgr, size=160)
        f2, found2 = crop_face(img2_bgr, size=160)
        sim = self.similarity(f1, f2)
        out = {"same_person": bool(sim >= self.threshold), "similarity": round(sim, 4),
               "threshold": self.threshold, "backend": self.backend, "faces_found": [found1, found2]}
        if not (found1 and found2):
            out["warning"] = "face not detected in one or both images; used a center crop"
        return out


def main(argv=None):
    ap = argparse.ArgumentParser(description="Verify whether two images show the same person")
    ap.add_argument("image1")
    ap.add_argument("image2")
    ap.add_argument("--backend", default="auto", choices=["auto", "facenet", "lbp"])
    ap.add_argument("--threshold", type=float, default=None)
    a = ap.parse_args(argv)
    imgs = [cv2.imread(p) for p in (a.image1, a.image2)]
    for p, im in zip((a.image1, a.image2), imgs):
        if im is None:
            raise SystemExit(f"Cannot read image: {p}")
    print(json.dumps(FaceVerifier(a.backend, a.threshold).verify(*imgs), indent=2))


if __name__ == "__main__":
    main()
