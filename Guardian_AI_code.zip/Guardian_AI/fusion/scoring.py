"""Fusion & scoring: combine module outputs into Authentic / Suspicious / Fake.

All inputs are optional (use whatever signals you have):
  deepfake_fake_prob : 0..1, higher = more likely manipulated   (deepfake.predict)
  liveness_score     : 0..1, higher = more likely a live person (liveness.liveness)
  similarity         : cosine similarity to the reference face  (face_verification.verify)

The weights and thresholds below are hand-set starting points, NOT calibrated.
Tune them on a validation set from your own data.

    python -m fusion.scoring --deepfake 0.2 --liveness 0.9 --similarity 0.7
"""
import argparse
import json

DEFAULT_WEIGHTS = {"deepfake": 0.5, "liveness": 0.25, "identity": 0.25}


def _clip(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, float(x)))


def identity_score(similarity, threshold=0.5, softness=0.3):
    """Map cosine similarity to 0..1: 0.5 at the threshold, 1.0 at threshold+softness."""
    return _clip(0.5 + 0.5 * (similarity - threshold) / softness)


def fuse(deepfake_fake_prob=None, liveness_score=None, similarity=None, id_threshold=0.5,
         weights=None, authentic_below=0.35, fake_above=0.65):
    risks = {}  # per-signal risk, 0 (good) .. 1 (bad)
    if deepfake_fake_prob is not None:
        risks["deepfake"] = _clip(deepfake_fake_prob)
    if liveness_score is not None:
        risks["liveness"] = 1.0 - _clip(liveness_score)
    if similarity is not None:
        risks["identity"] = 1.0 - identity_score(similarity, id_threshold)
    if not risks:
        raise ValueError("Give at least one signal (deepfake_fake_prob, liveness_score or similarity).")

    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    risk = sum(w[k] * r for k, r in risks.items()) / sum(w[k] for k in risks)

    label = "Authentic" if risk < authentic_below else ("Fake" if risk >= fake_above else "Suspicious")
    reasons = []
    if risks.get("deepfake", 0) >= 0.9:
        label = "Fake"
        reasons.append("deepfake model is very confident the media is manipulated")
    if label == "Authentic":  # one strongly bad signal should not be averaged away
        if risks.get("deepfake", 0) >= 0.6:
            reasons.append("deepfake score is high")
        if risks.get("liveness", 0) >= 0.8:
            reasons.append("liveness check failed")
        if risks.get("identity", 0) >= 0.8:
            reasons.append("face does not match the reference")
        if reasons:
            label = "Suspicious"
    else:
        if risks.get("deepfake", 0) >= 0.6:
            reasons.append("deepfake score is high")
        if risks.get("liveness", 0) >= 0.6:
            reasons.append("liveness is weak")
        if risks.get("identity", 0) >= 0.6:
            reasons.append("identity match is weak")
    if "deepfake" not in risks and label == "Fake":  # liveness/identity alone cannot prove manipulation
        label = "Suspicious"
        reasons.append("no deepfake score available, so the result is capped at Suspicious")
    if not reasons and label == "Authentic":
        reasons.append("all available signals look normal")

    return {
        "label": label,
        "risk_score": round(risk, 3),
        "signal_risks": {k: round(v, 3) for k, v in risks.items()},
        "reasons": reasons,
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description="Fuse signals into Authentic / Suspicious / Fake")
    ap.add_argument("--deepfake", type=float, help="fake probability 0..1")
    ap.add_argument("--liveness", type=float, help="live score 0..1")
    ap.add_argument("--similarity", type=float, help="cosine similarity")
    ap.add_argument("--id_threshold", type=float, default=0.5)
    a = ap.parse_args(argv)
    print(json.dumps(fuse(a.deepfake, a.liveness, a.similarity, a.id_threshold), indent=2))


if __name__ == "__main__":
    main()
