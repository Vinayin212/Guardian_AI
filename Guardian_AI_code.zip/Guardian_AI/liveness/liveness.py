"""Basic liveness checks from a short video (about 3-5 s): file path or webcam.

Signals: face visible, natural head micro-motion, blinking (eyes disappear for a few frames).
These are simple heuristics. They stop a still photo held to the camera, but a replayed video of
a real person (which blinks and moves) can pass. For real anti-spoofing add a trained
presentation-attack-detection model and/or a challenge-response step ("turn your head left").

    python -m liveness.liveness --video clip.mp4
    python -m liveness.liveness --webcam
"""
import argparse
import json
import os
import time

import cv2
import numpy as np

from deepfake.data_utils import read_consecutive_frames
from deepfake.face_crop import largest_face


def _load_eye_fn():
    if not hasattr(cv2, "CascadeClassifier"):
        return None
    base = getattr(getattr(cv2, "data", None), "haarcascades", None)
    path = os.environ.get("GUARDIAN_EYE_CASCADE") or (os.path.join(base, "haarcascade_eye.xml") if base else None)
    if not path or not os.path.exists(path):
        return None
    clf = cv2.CascadeClassifier(path)
    if clf.empty():
        return None

    def eye_fn(gray_upper_face):
        m = max(10, int(gray_upper_face.shape[1] * 0.12))
        return len(clf.detectMultiScale(gray_upper_face, 1.1, 5, minSize=(m, m)))

    return eye_fn


def count_blinks(eye_seq, fps):
    """eye_seq items: True = eyes seen, False = face seen but no eyes, None = no face."""
    min_closed = 2 if fps >= 20 else 1
    max_closed = max(3, int(0.6 * fps))
    blinks, seen_open, closed = 0, False, 0
    for s in eye_seq:
        if s is None:
            seen_open, closed = False, 0
        elif s:
            if seen_open and min_closed <= closed <= max_closed:
                blinks += 1
            seen_open, closed = True, 0
        elif seen_open:
            closed += 1
    return blinks


def _resize_max(frame, max_w=480):
    h, w = frame.shape[:2]
    if w <= max_w:
        return frame
    return cv2.resize(frame, None, fx=max_w / w, fy=max_w / w, interpolation=cv2.INTER_AREA)


def analyze_frames(frames, fps=30.0, face_fn=None, eye_fn="default"):
    """face_fn(frame) -> (x, y, w, h) or None; eye_fn(gray_upper_face) -> eye count (or None = unavailable)."""
    face_fn = face_fn or largest_face
    eye_fn = _load_eye_fn() if eye_fn == "default" else eye_fn
    frames = [_resize_max(f) for f in frames]
    boxes, eye_seq, sharp = [], [], []
    for f in frames:
        box = face_fn(f)
        boxes.append(box)
        if box is None:
            eye_seq.append(None)
            continue
        x, y, w, h = [int(v) for v in box]
        gray = cv2.cvtColor(f[max(0, y):y + h, max(0, x):x + w], cv2.COLOR_BGR2GRAY)
        if gray.size == 0:
            eye_seq.append(None)
            continue
        sharp.append(float(cv2.Laplacian(cv2.resize(gray, (128, 128)), cv2.CV_64F).var()))
        eye_seq.append(None if eye_fn is None else eye_fn(gray[: int(gray.shape[0] * 0.6)]) >= 1)

    n = max(len(frames), 1)
    found = [b for b in boxes if b is not None]
    face_ratio = len(found) / n
    motion = 0.0
    if len(found) >= 3:
        c = np.array([[b[0] + b[2] / 2, b[1] + b[3] / 2] for b in found], dtype=float)
        motion = float(np.mean(np.std(c, axis=0)) / max(np.mean([b[2] for b in found]), 1.0))
    blink_supported = eye_fn is not None
    blinks = count_blinks(eye_seq, fps) if blink_supported else 0

    face_score = min(face_ratio / 0.8, 1.0)
    motion_score = min(motion / 0.02, 1.0)  # saturates at 2 % of face width (heuristic)
    if blink_supported:
        live = 0.2 * face_score + 0.3 * motion_score + 0.5 * (1.0 if blinks >= 1 else 0.0)
    else:
        live = 0.4 * face_score + 0.6 * motion_score
    if face_ratio < 0.5:
        live = min(live, 0.3)
    is_live = bool(live >= 0.6 and motion_score >= 0.15)

    reasons = []
    if face_ratio < 0.5:
        reasons.append("face not visible in most frames")
    if motion_score < 0.15:
        reasons.append("almost no head movement (still photo?)")
    if blink_supported and blinks == 0:
        reasons.append("no blink detected")
    if not blink_supported:
        reasons.append("blink check unavailable (eye cascade not found)")
    return {"is_live": is_live, "live_score": round(float(live), 3), "frames": len(frames),
            "face_ratio": round(face_ratio, 3), "motion": round(motion, 4), "blinks": int(blinks),
            "sharpness": round(float(np.mean(sharp)), 1) if sharp else None,
            "blink_check": blink_supported, "reasons": reasons}


def analyze_video(path, max_frames=150):
    frames, fps = read_consecutive_frames(path, max_frames)
    if not frames:
        raise IOError(f"No frames could be read from {path}")
    return analyze_frames(frames, fps)


def run_webcam(seconds=4.0, camera=0):
    cap = cv2.VideoCapture(camera)
    if not cap.isOpened():
        raise IOError("Cannot open webcam")
    frames, start = [], time.time()
    while time.time() - start < seconds:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
        show = f.copy()
        cv2.putText(show, "Look at the camera and blink naturally", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        try:
            cv2.imshow("liveness", show)
            cv2.waitKey(1)
        except cv2.error:
            pass  # headless OpenCV build: no window, still records
    cap.release()
    try:
        cv2.destroyAllWindows()
    except cv2.error:
        pass
    fps = len(frames) / max(time.time() - start, 1e-6)
    return analyze_frames(frames, fps)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Basic liveness check")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--video")
    g.add_argument("--webcam", action="store_true")
    ap.add_argument("--seconds", type=float, default=4.0)
    a = ap.parse_args(argv)
    print(json.dumps(analyze_video(a.video) if a.video else run_webcam(a.seconds), indent=2))


if __name__ == "__main__":
    main()
