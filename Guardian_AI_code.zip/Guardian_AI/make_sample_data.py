"""Generate a tiny SYNTHETIC dataset (cartoon faces) to test the pipeline end to end.
It is not real deepfake data: 'fake' faces just carry crude artifacts. Use download_data.py for real data.

  python make_sample_data.py --out sample_data --n 40 --videos 3
"""
import argparse
import os

import cv2
import numpy as np
from PIL import Image, ImageDraw


def make_face(rng, fake, size=224, eyes_open=True, shift=(0, 0)):
    bg = tuple(int(v) for v in rng.integers(40, 200, 3))
    im = Image.new("RGB", (size, size), bg)
    d = ImageDraw.Draw(im)
    skin = tuple(int(v) for v in rng.integers([180, 130, 100], [255, 200, 170]))
    cx, cy = size // 2 + shift[0], size // 2 + shift[1]
    rw, rh = int(rng.integers(55, 75)), int(rng.integers(70, 90))
    d.ellipse([cx - rw, cy - rh, cx + rw, cy + rh], fill=skin)
    ey, ex = cy - rh // 4, rw // 2
    for s in (-1, 1):
        x = cx + s * ex
        if eyes_open:
            d.ellipse([x - 12, ey - 7, x + 12, ey + 7], fill=(255, 255, 255))
            d.ellipse([x - 5, ey - 5, x + 5, ey + 5], fill=(30, 30, 30))
        else:
            d.line([x - 12, ey, x + 12, ey], fill=(60, 30, 30), width=3)
    d.arc([cx - 25, cy + 10, cx + 25, cy + 45], 20, 160, fill=(150, 40, 40), width=4)
    arr = np.asarray(im).astype(np.float32) + rng.normal(0, 3, (size, size, 3))
    if fake:  # crude traces: periodic grid pattern + a smoothed, colour-shifted cheek patch
        yy, xx = np.mgrid[0:size, 0:size]
        arr += 6 * (np.sin(xx * np.pi / 2) * np.sin(yy * np.pi / 2))[..., None]
        y0, x0 = cy, cx - rw // 2
        region = np.clip(arr[y0:y0 + 40, x0:x0 + 50], 0, 255).astype(np.uint8)
        arr[y0:y0 + 40, x0:x0 + 50] = cv2.GaussianBlur(region, (0, 0), 3).astype(np.float32) + np.array([8, -8, 0])
    return np.clip(arr, 0, 255).astype(np.uint8)[:, :, ::-1].copy()  # RGB -> BGR for OpenCV


def write_video(path, rng, fake, frames=45, fps=15, size=224):
    seed = int(rng.integers(0, 10**9))
    ext_fourcc = [("mp4v", ".mp4"), ("MJPG", ".avi")]
    for fourcc, ext in ext_fourcc:
        out_path = os.path.splitext(path)[0] + ext
        w = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*fourcc), fps, (size, size))
        if not w.isOpened():
            continue
        for i in range(frames):
            r = np.random.default_rng(seed)  # same face every frame
            shift = (int(6 * np.sin(i / 4)), int(4 * np.cos(i / 5)))
            w.write(make_face(r, fake, size, eyes_open=(i % 20) not in (9, 10, 11), shift=shift))
        w.release()
        if os.path.getsize(out_path) > 0:
            return out_path
    return None


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sample_data")
    ap.add_argument("--n", type=int, default=40, help="images per class")
    ap.add_argument("--videos", type=int, default=3, help="videos per class")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args(argv)
    rng = np.random.default_rng(a.seed)
    for cls in ("real", "fake"):
        for sub in ("images", "videos"):
            os.makedirs(os.path.join(a.out, sub, cls), exist_ok=True)
        for i in range(a.n):
            cv2.imwrite(os.path.join(a.out, "images", cls, f"{cls}_{i:03d}.jpg"), make_face(rng, cls == "fake"),
                        [cv2.IMWRITE_JPEG_QUALITY, 92])
        for i in range(a.videos):
            write_video(os.path.join(a.out, "videos", cls, f"{cls}_{i:02d}.mp4"), rng, cls == "fake")
    print(f"sample data written to {a.out}/  (images/ and videos/, each with real/ and fake/)")


if __name__ == "__main__":
    main()
