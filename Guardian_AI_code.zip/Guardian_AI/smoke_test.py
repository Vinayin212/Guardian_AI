"""End-to-end check on synthetic data. Run from the project root:  python smoke_test.py
Stages that need PyTorch/timm/FastAPI are skipped (not failed) when those packages are missing.
"""
import glob
import importlib.util
import shutil
import sys
import traceback

import cv2

RESULTS = []
WORK = ".smoke"


def step(name, fn):
    try:
        note = fn()
        RESULTS.append((name, "PASS", note or ""))
    except Skip as s:
        RESULTS.append((name, "SKIP", str(s)))
    except Exception:
        RESULTS.append((name, "FAIL", traceback.format_exc(limit=3)))


class Skip(Exception):
    pass


def need(pkg):
    if importlib.util.find_spec(pkg) is None:
        raise Skip(f"{pkg} not installed")


def n_files(pattern):
    return len(glob.glob(pattern))


def t_generate():
    import make_sample_data
    shutil.rmtree(WORK, ignore_errors=True)
    make_sample_data.main(["--out", f"{WORK}/sample", "--n", "24", "--videos", "2"])
    assert n_files(f"{WORK}/sample/images/real/*.jpg") == 24
    assert n_files(f"{WORK}/sample/videos/fake/*") >= 1, "no video written (codec missing?)"


def t_frames():
    from deepfake import extract_frames
    extract_frames.main(["--src_root", f"{WORK}/sample/videos", "--dst_root", f"{WORK}/frames",
                         "--every", "5", "--max_frames", "6"])
    assert n_files(f"{WORK}/frames/real/*.jpg") > 0
    return f"{n_files(f'{WORK}/frames/*/*.jpg')} frames"


def t_crop():
    from deepfake import face_crop
    face_crop.main(["--src_root", f"{WORK}/sample/images", "--dst_root", f"{WORK}/data"])
    r, f = n_files(f"{WORK}/data/real/*.jpg"), n_files(f"{WORK}/data/fake/*.jpg")
    assert r == 24 and f == 24, (r, f)
    return "cartoon faces -> center-crop fallback is expected here"


def t_split():
    from deepfake.data_utils import group_key, group_split, list_samples
    items = list_samples(f"{WORK}/frames") + list_samples(f"{WORK}/data")
    tr, va = group_split(items, 0.25, 1)
    assert tr and va
    assert not ({group_key(p) for p, y in tr} & {group_key(p) for p, y in va}), "group leakage"
    return f"train={len(tr)} val={len(va)}"


def t_fusion():
    from fusion.scoring import fuse
    assert fuse(0.05, 0.95, 0.8)["label"] == "Authentic"
    assert fuse(0.95)["label"] == "Fake"
    assert fuse(0.1, 0.0, 0.0)["label"] == "Suspicious"
    assert fuse(liveness_score=0.9)["label"] == "Authentic"


def t_verify():
    from face_verification.verify import FaceVerifier
    a = cv2.imread(sorted(glob.glob(f"{WORK}/data/real/*.jpg"))[0])
    b = cv2.imread(sorted(glob.glob(f"{WORK}/data/real/*.jpg"))[1])
    v = FaceVerifier("auto")
    same, diff = v.verify(a, a), v.verify(a, b)
    assert same["similarity"] >= diff["similarity"]
    return f"backend={v.backend} same={same['similarity']} diff={diff['similarity']}"


def t_liveness():
    from liveness.liveness import analyze_frames, analyze_video
    # logic test with injected detectors: face wobbles, eyes vanish for 3 frames -> 1 blink
    frames = [cv2.imread(sorted(glob.glob(f"{WORK}/data/real/*.jpg"))[0])] * 40
    state = {"i": -1}

    def face_fn(_):
        state["i"] += 1
        return (60 + (state["i"] % 7), 50 + (state["i"] % 5), 100, 120)

    eyes_closed = {15, 16, 17}
    eye_calls = {"i": -1}

    def eye_fn(_):
        eye_calls["i"] += 1
        return 0 if eye_calls["i"] in eyes_closed else 2

    r = analyze_frames(frames, fps=30, face_fn=face_fn, eye_fn=eye_fn)
    assert r["blinks"] == 1 and r["is_live"], r
    still = analyze_frames(frames, fps=30, face_fn=lambda _: (60, 50, 100, 120), eye_fn=lambda _: 2)
    assert not still["is_live"], still
    v = sorted(glob.glob(f"{WORK}/sample/videos/*/*"))[0]
    analyze_video(v)  # must run without error (score is not meaningful on cartoon faces)


def t_torch():
    need("torch")
    need("timm")
    from deepfake import evaluate, predict, train_vit
    train_vit.main(["--data", f"{WORK}/data", "--epochs", "1", "--batch", "8", "--no_pretrained",
                    "--out", f"{WORK}/models/m.pt"])
    img = sorted(glob.glob(f"{WORK}/data/fake/*.jpg"))[0]
    vid = sorted(glob.glob(f"{WORK}/sample/videos/fake/*"))[0]
    det = predict.DeepfakeDetector(f"{WORK}/models/m.pt")
    assert 0 <= det.predict_path(img)["fake_prob"] <= 1
    assert 0 <= det.predict_path(vid)["fake_prob"] <= 1
    evaluate.main(["--ckpt", f"{WORK}/models/m.pt", "--split", f"{WORK}/models/split.json", "--out", f"{WORK}/reports"])
    evaluate.main(["--ckpt", f"{WORK}/models/m.pt", "--explain", img, "--out", f"{WORK}/reports"])


def t_api():
    need("fastapi")
    from api import main as api_main
    assert api_main.health()["status"] == "ok"


for name, fn in [("generate sample data", t_generate), ("extract frames", t_frames), ("face crop", t_crop),
                 ("group split", t_split), ("fusion", t_fusion), ("face verification", t_verify),
                 ("liveness", t_liveness), ("train/predict/evaluate (torch)", t_torch), ("api import", t_api)]:
    step(name, fn)

print("\n=== smoke test ===")
for name, status, note in RESULTS:
    print(f"[{status}] {name}" + (f"  - {note}" if note else ""))
sys.exit(1 if any(s == "FAIL" for _, s, _ in RESULTS) else 0)
